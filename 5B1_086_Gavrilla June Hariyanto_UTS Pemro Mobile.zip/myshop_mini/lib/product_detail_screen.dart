import 'package:flutter/material.dart';
import 'models.dart';

class ProductDetailScreen extends StatelessWidget {
  final Product product;

  ProductDetailScreen({required this.product});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Detail Produk")),
      body: Center(
        child: Card(
          color: product.color,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
          elevation: 6,
          child: Container(
            width: 300,
            padding: EdgeInsets.all(32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(product.icon, size: 90, color: textDark),
                SizedBox(height: 20),
                Text(
                  product.name,
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: textDark),
                ),
                SizedBox(height: 10),
                Text(
                  "Rp ${product.price}",
                  style: TextStyle(fontSize: 22, color: textDark),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}