import 'package:flutter/material.dart';

class Category {
  final String name;
  final IconData icon;
  final Color color;

  Category({required this.name, required this.icon, required this.color});
}

class Product {
  final String name;
  final int price;
  final IconData icon;
  final String category;
  final Color color;

  Product({
    required this.name,
    required this.price,
    required this.icon,
    required this.category,
    required this.color,
  });
}

// WARNA PASTEL
const pastelBlue = Color(0xFFD7ECFF);
const pastelPink = Color(0xFFFFD6E8);
const pastelGreen = Color(0xFFD8FFEA);
const pastelYellow = Color(0xFFFFF5CC);
const pastelPurple = Color(0xFFEAD8FF);
const textDark = Color(0xFF3A3A3A);

// KATEGORI
final List<Category> categories = [
  Category(name: 'Makanan', icon: Icons.fastfood, color: pastelPink),
  Category(name: 'Minuman', icon: Icons.local_drink, color: pastelGreen),
  Category(name: 'Elektronik', icon: Icons.devices, color: pastelPurple),
];

// PRODUK (warna konsisten!)
final List<Product> products = [
  Product(name: 'Nasi Goreng', price: 15000, icon: Icons.rice_bowl, category: 'Makanan', color: pastelPink),
  Product(name: 'Burger', price: 20000, icon: Icons.lunch_dining, category: 'Makanan', color: pastelPink),

  Product(name: 'Teh Botol', price: 5000, icon: Icons.local_drink, category: 'Minuman', color: pastelGreen),
  Product(name: 'Kopi Hitam', price: 8000, icon: Icons.coffee, category: 'Minuman', color: pastelGreen),

  Product(name: 'Headset', price: 75000, icon: Icons.headphones, category: 'Elektronik', color: pastelPurple),
  Product(name: 'Keyboard', price: 120000, icon: Icons.keyboard, category: 'Elektronik', color: pastelPurple),
];