import 'package:flutter/material.dart';
import 'models.dart';
import 'product_detail_screen.dart';

class ProductListScreen extends StatelessWidget {
  final String category;
  final Color cardColor;

  ProductListScreen({required this.category, required this.cardColor});

  @override
  Widget build(BuildContext context) {
    List<Product> filtered = products.where((p) => p.category == category).toList();

    return Scaffold(
      appBar: AppBar(title: Text(category)),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: GridView.builder(
          itemCount: filtered.length,
          gridDelegate:
              SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 0.8),
          itemBuilder: (context, index) {
            final product = filtered[index];

            return GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => ProductDetailScreen(product: product)),
                );
              },
              child: Card(
                color: product.color,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                elevation: 4,
                child: Container(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(product.icon, size: 50, color: textDark),
                      SizedBox(height: 10),
                      Text(product.name,
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold, color: textDark)),
                      SizedBox(height: 5),
                      Text("Rp ${product.price}",
                          style: TextStyle(fontSize: 14, color: textDark)),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}