package com.example.myshop_mini

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
